DELETE FROM `#__modules` WHERE `module` = 'mod_stockwatch' AND `published` = 0;
