<?php

	class modStockHelper{
		function getStocks($params){
			return 'This is a stock information';
		}
	}
?>