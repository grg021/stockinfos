drop table #__stockinfos;
DELETE FROM #__categories where extension = 'stockinfos';